import { Spinner } from 'reactstrap'

const SpinnerFloat = () => {
  return <Spinner className='float-right mb-2' />
}
export default SpinnerFloat
