<?php $__env->startSection('title', 'Clipboard'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendors/css/extensions/toastr.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/base/plugins/extensions/ext-component-toastr.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Copy to clipboard -->
<section id="copy-to-clipboard">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Clipboard</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-xl-3 col-md-4 col-sm-6 col-12 pe-sm-0">
              <div class="mb-1">
                <input type="text" class="form-control" id="copy-to-clipboard-input" value="Copy Me!" />
              </div>
            </div>
            <div class="col-sm-2 col-12">
              <button class="btn btn-outline-primary" id="btn-copy">Copy!</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ Copy to clipboard -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/js/extensions/toastr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
<!-- Page js files -->
<script src="<?php echo e(asset(mix('js/scripts/extensions/ext-component-clipboard.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//content/extensions/ext-component-clipboard.blade.php ENDPATH**/ ?>