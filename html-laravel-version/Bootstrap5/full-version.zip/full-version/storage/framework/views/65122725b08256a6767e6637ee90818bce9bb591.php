<?php
$breadcrumbs = [['link' => 'home', 'name' => 'Home'], ['link' => 'javascript:void(0)', 'name' => 'User'], ['name' => 'Profile']];
?>

<?php $__env->startSection('title', 'Profile'); ?>


<?php $__env->startSection('content'); ?>

  <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.update-profile-information-form')->html();
} elseif ($_instance->childHasBeenRendered('xXQQFIG')) {
    $componentId = $_instance->getRenderedChildComponentId('xXQQFIG');
    $componentTag = $_instance->getRenderedChildComponentTagName('xXQQFIG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xXQQFIG');
} else {
    $response = \Livewire\Livewire::mount('profile.update-profile-information-form');
    $html = $response->html();
    $_instance->logRenderedChild('xXQQFIG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php endif; ?>

  <?php if(Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::updatePasswords())): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.update-password-form')->html();
} elseif ($_instance->childHasBeenRendered('SpIfA1f')) {
    $componentId = $_instance->getRenderedChildComponentId('SpIfA1f');
    $componentTag = $_instance->getRenderedChildComponentTagName('SpIfA1f');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SpIfA1f');
} else {
    $response = \Livewire\Livewire::mount('profile.update-password-form');
    $html = $response->html();
    $_instance->logRenderedChild('SpIfA1f', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php endif; ?>

  <?php if(Laravel\Fortify\Features::canManageTwoFactorAuthentication()): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.two-factor-authentication-form')->html();
} elseif ($_instance->childHasBeenRendered('2vaImJN')) {
    $componentId = $_instance->getRenderedChildComponentId('2vaImJN');
    $componentTag = $_instance->getRenderedChildComponentTagName('2vaImJN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2vaImJN');
} else {
    $response = \Livewire\Livewire::mount('profile.two-factor-authentication-form');
    $html = $response->html();
    $_instance->logRenderedChild('2vaImJN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php endif; ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.logout-other-browser-sessions-form')->html();
} elseif ($_instance->childHasBeenRendered('jNbrdYE')) {
    $componentId = $_instance->getRenderedChildComponentId('jNbrdYE');
    $componentTag = $_instance->getRenderedChildComponentTagName('jNbrdYE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jNbrdYE');
} else {
    $response = \Livewire\Livewire::mount('profile.logout-other-browser-sessions-form');
    $html = $response->html();
    $_instance->logRenderedChild('jNbrdYE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

  <?php if(Laravel\Jetstream\Jetstream::hasAccountDeletionFeatures()): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.delete-user-form')->html();
} elseif ($_instance->childHasBeenRendered('mJwyfys')) {
    $componentId = $_instance->getRenderedChildComponentId('mJwyfys');
    $componentTag = $_instance->getRenderedChildComponentTagName('mJwyfys');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mJwyfys');
} else {
    $response = \Livewire\Livewire::mount('profile.delete-user-form');
    $html = $response->html();
    $_instance->logRenderedChild('mJwyfys', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views/profile/show.blade.php ENDPATH**/ ?>