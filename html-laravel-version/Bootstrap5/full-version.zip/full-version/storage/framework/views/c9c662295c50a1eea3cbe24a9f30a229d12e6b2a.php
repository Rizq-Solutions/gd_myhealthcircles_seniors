<?php
$breadcrumbs = [['link' => 'home', 'name' => 'Home'], ['name' => 'Create Team']];
?>
<?php $__env->startSection('title', 'Create Team'); ?>

<?php $__env->startSection('content'); ?>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teams.create-team-form')->html();
} elseif ($_instance->childHasBeenRendered('dFCZQZw')) {
    $componentId = $_instance->getRenderedChildComponentId('dFCZQZw');
    $componentTag = $_instance->getRenderedChildComponentTagName('dFCZQZw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dFCZQZw');
} else {
    $response = \Livewire\Livewire::mount('teams.create-team-form');
    $html = $response->html();
    $_instance->logRenderedChild('dFCZQZw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views/teams/create.blade.php ENDPATH**/ ?>