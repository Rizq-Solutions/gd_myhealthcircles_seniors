<?php
$breadcrumbs = [['link' => 'home', 'name' => 'Home'], ['name' => 'Team Settings']];
?>

<?php $__env->startSection('title', 'Team Settings'); ?>

<?php $__env->startSection('content'); ?>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teams.update-team-name-form', ['team' => $team])->html();
} elseif ($_instance->childHasBeenRendered('qHrqc8J')) {
    $componentId = $_instance->getRenderedChildComponentId('qHrqc8J');
    $componentTag = $_instance->getRenderedChildComponentTagName('qHrqc8J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qHrqc8J');
} else {
    $response = \Livewire\Livewire::mount('teams.update-team-name-form', ['team' => $team]);
    $html = $response->html();
    $_instance->logRenderedChild('qHrqc8J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teams.team-member-manager', ['team' => $team])->html();
} elseif ($_instance->childHasBeenRendered('qRx3V1B')) {
    $componentId = $_instance->getRenderedChildComponentId('qRx3V1B');
    $componentTag = $_instance->getRenderedChildComponentTagName('qRx3V1B');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qRx3V1B');
} else {
    $response = \Livewire\Livewire::mount('teams.team-member-manager', ['team' => $team]);
    $html = $response->html();
    $_instance->logRenderedChild('qRx3V1B', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

  <?php if(Gate::check('delete', $team) && !$team->personal_team): ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teams.delete-team-form', ['team' => $team])->html();
} elseif ($_instance->childHasBeenRendered('dzSH2EA')) {
    $componentId = $_instance->getRenderedChildComponentId('dzSH2EA');
    $componentTag = $_instance->getRenderedChildComponentTagName('dzSH2EA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dzSH2EA');
} else {
    $response = \Livewire\Livewire::mount('teams.delete-team-form', ['team' => $team]);
    $html = $response->html();
    $_instance->logRenderedChild('dzSH2EA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views/teams/show.blade.php ENDPATH**/ ?>