<div class="card">
  <div class="card-header">
    <h4 class="card-title"><?php echo e($title); ?></h4>
  </div>
  <div class="card-body">
    <p class="card-text text-muted">
      <?php echo e($description); ?>

    </p>
    <?php echo e($content); ?>

  </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views/vendor/jetstream/components/action-section.blade.php ENDPATH**/ ?>