<div class="blog-sidebar my-2 my-lg-0">
  <!-- Search bar -->
  <div class="blog-search">
    <div class="input-group input-group-merge">
      <input type="text" class="form-control" placeholder="Search here" />
      <span class="input-group-text cursor-pointer">
        <i data-feather="search"></i>
      </span>
    </div>
  </div>
  <!--/ Search bar -->

  <!-- Recent Posts -->
  <div class="blog-recent-posts mt-3">
    <h6 class="section-label">Recent Posts</h6>
    <div class="mt-75">
      <div class="d-flex mb-2">
        <a href="<?php echo e(asset('page/blog/detail')); ?>" class="me-2">
          <img
            class="rounded"
            src="<?php echo e(asset('images/banner/banner-22.jpg')); ?>"
            width="100"
            height="70"
            alt="Recent Post Pic"
          />
        </a>
        <div class="blog-info">
          <h6 class="blog-recent-post-title">
            <a href="<?php echo e(asset('page/blog/detail')); ?>" class="text-body-heading">Why Should Forget Facebook?</a>
          </h6>
          <div class="text-muted mb-0">Jan 14 2020</div>
        </div>
      </div>
      <div class="d-flex mb-2">
        <a href="<?php echo e(asset('page/blog/detail')); ?>" class="me-2">
          <img
            class="rounded"
            src="<?php echo e(asset('images/banner/banner-27.jpg')); ?>"
            width="100"
            height="70"
            alt="Recent Post Pic"
          />
        </a>
        <div class="blog-info">
          <h6 class="blog-recent-post-title">
            <a href="<?php echo e(asset('page/blog/detail')); ?>" class="text-body-heading">Publish your passions, your way</a>
          </h6>
          <div class="text-muted mb-0">Mar 04 2020</div>
        </div>
      </div>
      <div class="d-flex mb-2">
        <a href="<?php echo e(asset('page/blog/detail')); ?>" class="me-2">
          <img
            class="rounded"
            src="<?php echo e(asset('images/banner/banner-39.jpg')); ?>"
            width="100"
            height="70"
            alt="Recent Post Pic"
          />
        </a>
        <div class="blog-info">
          <h6 class="blog-recent-post-title">
            <a href="<?php echo e(asset('page/blog/detail')); ?>" class="text-body-heading">The Best Ways to Retain More</a>
          </h6>
          <div class="text-muted mb-0">Feb 18 2020</div>
        </div>
      </div>
      <div class="d-flex">
        <a href="<?php echo e(asset('page/blog/detail')); ?>" class="me-2">
          <img
            class="rounded"
            src="<?php echo e(asset('images/banner/banner-35.jpg')); ?>"
            width="100"
            height="70"
            alt="Recent Post Pic"
          />
        </a>
        <div class="blog-info">
          <h6 class="blog-recent-post-title">
            <a href="<?php echo e(asset('page/blog/detail')); ?>" class="text-body-heading">Share a Shocking Fact or Statistic</a>
          </h6>
          <div class="text-muted mb-0">Oct 08 2020</div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Recent Posts -->

  <!-- Categories -->
  <div class="blog-categories mt-3">
    <h6 class="section-label">Categories</h6>
    <div class="mt-1">
      <div class="d-flex justify-content-start align-items-center mb-75">
        <a href="#" class="me-75">
          <div class="avatar bg-light-primary rounded">
            <div class="avatar-content">
              <i data-feather="watch" class="avatar-icon font-medium-1"></i>
            </div>
          </div>
        </a>
        <a href="#">
          <div class="blog-category-title text-body">Fashion</div>
        </a>
      </div>
      <div class="d-flex justify-content-start align-items-center mb-75">
        <a href="#" class="me-75">
          <div class="avatar bg-light-success rounded">
            <div class="avatar-content">
              <i data-feather="shopping-cart" class="avatar-icon font-medium-1"></i>
            </div>
          </div>
        </a>
        <a href="#">
          <div class="blog-category-title text-body">Food</div>
        </a>
      </div>
      <div class="d-flex justify-content-start align-items-center mb-75">
        <a href="#" class="me-75">
          <div class="avatar bg-light-danger rounded">
            <div class="avatar-content">
              <i data-feather="command" class="avatar-icon font-medium-1"></i>
            </div>
          </div>
        </a>
        <a href="#">
          <div class="blog-category-title text-body">Gaming</div>
        </a>
      </div>
      <div class="d-flex justify-content-start align-items-center mb-75">
        <a href="#" class="me-75">
          <div class="avatar bg-light-info rounded">
            <div class="avatar-content">
              <i data-feather="hash" class="avatar-icon font-medium-1"></i>
            </div>
          </div>
        </a>
        <a href="#">
          <div class="blog-category-title text-body">Quote</div>
        </a>
      </div>
      <div class="d-flex justify-content-start align-items-center">
        <a href="#" class="me-75">
          <div class="avatar bg-light-warning rounded">
            <div class="avatar-content">
              <i data-feather="video" class="avatar-icon font-medium-1"></i>
            </div>
          </div>
        </a>
        <a href="#">
          <div class="blog-category-title text-body">Video</div>
        </a>
      </div>
    </div>
  </div>
  <!--/ Categories -->
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//content/pages/page-blog-sidebar.blade.php ENDPATH**/ ?>